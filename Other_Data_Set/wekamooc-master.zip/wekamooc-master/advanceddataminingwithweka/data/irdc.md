IDRC
====

2014 conference
---------------

http://cnirs.clubexpress.com/content.aspx?page_id=22&club_id=409746&module_id=141692&sl=343518522

Shootout
--------

http://cnirs.clubexpress.com/content.aspx?page_id=22&club_id=409746&module_id=146232


