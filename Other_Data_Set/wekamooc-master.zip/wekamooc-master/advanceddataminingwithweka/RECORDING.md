RECORDING
=========

Schedule
--------

Mon/Fri available -> Bronwyn/Marian open office


Recording
---------

 * see Ian's notes
 * LifeCam settings pop up on the right hand side
 * record everything, create list of edits for person in charge of video editing
 * put slides on the right hand side next to recorded area
 * after recording:
 
  * save + edit, save in `C:\MOOC Advanced Data Mining with Weka`, 
    starts up Camtasia Studio
  * Camtasia Studio: ignore output settings, just exit, don't save project

