Advanced Data Mining with Weka
==============================

The third MOOC on Weka.

https://weka.waikato.ac.nz/advanceddataminingwithweka/

Materials website (videos, slides, etc):

http://www.cs.waikato.ac.nz/~ml/weka/mooc/advanceddataminingwithweka/


Python (.py)
============

These code examples use the following Python library (0.2.0 or later):

https://pypi.python.org/pypi/python-weka-wrapper

Please be aware that the MOOC is based on Weka 3.6.11, 
whereas this library uses the 3.7.x branch (developer version).
